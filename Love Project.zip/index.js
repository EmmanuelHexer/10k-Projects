const bodyEl = document.body;

bodyEl.addEventListener("mousemove", (e) => {
  const xPos = e.offsetX;
  const yPos = e.offsetY;
  const spanEl = document.createElement("span");
  const size = Math.random() * 150;
  bodyEl.appendChild(spanEl);
  spanEl.style.left = xPos + "px";
  spanEl.style.top = yPos + "px";
  spanEl.style.width = size + "px";
  spanEl.style.height = size + "px";
  setTimeout(() => {
    spanEl.remove();
  }, 2000);
});
